@extends('layouts.app')
@section('content')<h1>Payments</h1>@endsection