@extends('layouts.app')
@section('content')<h1>Contributions</h1>@endsection