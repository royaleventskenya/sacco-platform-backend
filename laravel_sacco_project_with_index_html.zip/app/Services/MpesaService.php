<?php
namespace App\Services;
class MpesaService {
  public function initiateStkPush($phone, $amount) {
    // Integrate with Daraja API
  }
}