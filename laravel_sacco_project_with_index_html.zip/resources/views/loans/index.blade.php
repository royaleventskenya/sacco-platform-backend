@extends('layouts.app')
@section('content')<h1>Loans</h1>@endsection